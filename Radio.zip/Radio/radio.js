const radioSlides = document.getElementById("radio-slides");
const radioSlideElements = document.querySelectorAll(".radio-slide");
const totalSlides = radioSlideElements.length;
let currentSlide = 0;

// Función para actualizar el slider
function updateSlider() {
    // Detener todos los reproductores de audio
    const audioPlayers = document.querySelectorAll(".radio-slide audio");
    audioPlayers.forEach((audio, index) => {
        if (index !== currentSlide) {
            audio.pause(); // Detener audio
            audio.currentTime = 0; // Reiniciar tiempo
        }
    });

    // Reproducir el audio del slide actual
    const currentAudio = radioSlideElements[currentSlide].querySelector("audio");
    if (currentAudio) {
        currentAudio.play();
    }

    // Actualizar posición del slider
    radioSlides.style.transform = `translateX(-${currentSlide * 100}%)`;
}

// Botón anterior
document.getElementById("prev").addEventListener("click", () => {
    currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
    updateSlider();
});

// Botón siguiente
document.getElementById("next").addEventListener("click", () => {
    currentSlide = (currentSlide + 1) % totalSlides; // Move to the next slide
    updateSlider();
});

// Inicializar el slider
updateSlider();